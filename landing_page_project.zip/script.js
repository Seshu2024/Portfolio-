
// Smooth scroll for navbar
document.querySelectorAll('a[href^="#"]').forEach(link => {
  link.addEventListener("click", function(e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute("href"));
    if (target) {
      target.scrollIntoView({ behavior: "smooth" });
    }
  });
});

// Scroll-to-top button
const scrollBtn = document.getElementById("scrollToTopBtn");
window.addEventListener("scroll", () => {
  scrollBtn.style.display = window.scrollY > 400 ? "block" : "none";
});
scrollBtn.addEventListener("click", () => {
  window.scrollTo({ top: 0, behavior: "smooth" });
});

// FAQ toggle
const questions = document.querySelectorAll(".faq-question");
questions.forEach(btn => {
  btn.addEventListener("click", () => {
    const answer = btn.nextElementSibling;
    const isOpen = answer.style.display === "block";
    document.querySelectorAll(".faq-answer").forEach(a => a.style.display = "none");
    answer.style.display = isOpen ? "none" : "block";
  });
});

// Reveal on scroll
function revealOnScroll() {
  const reveals = document.querySelectorAll(".reveal");
  reveals.forEach(elem => {
    const windowHeight = window.innerHeight;
    const elementTop = elem.getBoundingClientRect().top;
    const offset = 100;
    if (elementTop < windowHeight - offset) {
      elem.classList.add("active");
    }
  });
}
window.addEventListener("scroll", revealOnScroll);
